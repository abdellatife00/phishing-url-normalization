# Source and claim checks

## Feshchenko, Vitvitska and Luchyk (2026)
Robust Detection of Phishing URLs Under Obfuscation Attacks. Social Development and Security, 16(4), 192-207.
https://doi.org/10.33445/sds.2026.16.4.10
Publisher: https://paperssds.eu/index.php/JSPSDS/article/view/1189

The teacher-recommended paper describes www stripping, fragment removal and unreserved decoding in its canonicalization procedure (printed p. 197). Its main model comparison is raw, dual-view and robust augmented. The revised investigation adds normalized-only and individual-operation comparisons to that selected study's main design. Do not claim that this gap has never been investigated anywhere in the literature, or that our implementation is an exact reproduction.

## Berners-Lee, Fielding and Masinter (2005), RFC 3986
https://www.rfc-editor.org/rfc/rfc3986
Sections 2.3, 3.2.2 and 3.5 distinguish unreserved characters, the hostname and fragment. www removal is not a generally valid equivalence rule. A fragment can identify a secondary resource. The paper therefore treats the experiment as feature removal, not live-resource equivalence.

## Marchal and Asokan (2018)
https://www.usenix.org/conference/cset18/presentation/marchal
Supports discussion of benchmark evaluation and representative data. It is not evidence for the numerical results of this investigation.

## Pedregosa et al. (2011)
https://www.jmlr.org/papers/v12/pedregosa11a.html
Standard scikit-learn software citation, volume 12, pages 2825-2830. The actual executed version is 1.8.0 and is separately recorded in environment.json.

## Prasad and Chandra (2024), UCI dataset 967
https://archive.ics.uci.edu/dataset/967/phiusiil+phishing+url+dataset
Official entry verifies 235,795 rows, class counts, original label convention, creators and CC BY 4.0 license. The 30,000-row subset and its biases are measurements from our own sample, not claims that the publisher independently verified this experiment.

## Numerical evidence
Tables and figure are generated from results/metrics.csv, results/comparisons.csv and coverage.json. check_results.py verifies confusion counts, accuracy, F1 and paired error counts directly from saved predictions. www_subgroups.csv shows that new errors after retraining occur on originally non-www phishing URLs. error_concentration.json reports a post-hoc concentration check; it is not a pre-specified primary outcome.

## Limits on conclusions
No conflicting-label normalization collisions were found in the sample. This is evidence of pipeline sensitivity and dataset dependence, not proof of unavoidable information-theoretic classification error. Combined representations recovered much of the normalized-only loss but did not outperform original-only overall. The original sample and splits were reused; external confirmation is outstanding.
