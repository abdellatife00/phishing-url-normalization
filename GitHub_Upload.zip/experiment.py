"""Offline follow-up: ablate URL information, without visiting dataset addresses."""
import os
os.environ['OPENBLAS_NUM_THREADS']='2'
os.environ['OMP_NUM_THREADS']='2'
import json,re,time,hashlib,platform,importlib.metadata
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.sparse import hstack
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GroupShuffleSplit
from sklearn.metrics import confusion_matrix,f1_score
from threadpoolctl import threadpool_limits
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'results';OUT.mkdir(exist_ok=True)
SEEDS=[42,43,44]
OPS=['www','fragment','unreserved','combined']
UNRESERVED=set('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~')
def transform(u,op):
    if op in ('www','combined'):
        u=re.sub(r'^(https?://)www\.',r'\1',u,count=1,flags=re.I)
    if op in ('fragment','combined'):u=u.split('#',1)[0]
    if op in ('unreserved','combined'):
        # Restrict to path/query; preserve authority and fragment.
        m=re.fullmatch(r'(https?://[^/?#]+)([^#]*)(.*)',u,re.I)
        tail=re.sub(r'%([0-9a-fA-F]{2})',lambda x: chr(int(x[1],16)) if chr(int(x[1],16)) in UNRESERVED else x[0],m[2])
        u=m[1]+tail+m[3]
    return u
def checks():
    assert transform('https://www.example.com/A?x=1#z','www')=='https://example.com/A?x=1#z'
    assert transform('https://www2.example.com/A','www')=='https://www2.example.com/A'
    assert transform('https://example.com/%41%2f?q=%7e#%41','unreserved')=='https://example.com/A%2f?q=~#%41'
    assert transform('https://example.com/A#z','fragment')=='https://example.com/A'
def vectorizer(n=50000):return TfidfVectorizer(analyzer='char',ngram_range=(3,5),lowercase=True,min_df=2,max_features=n,sublinear_tf=True,norm='l2',dtype=np.float64)
def model():return LogisticRegression(C=1,solver='liblinear',max_iter=1000,random_state=0)
def metrics(y,p):
    tn,fp,fn,tp=map(int,confusion_matrix(y,p,labels=[0,1]).ravel())
    return dict(n=len(y),tn=tn,fp=fp,fn=fn,tp=tp,accuracy=float(np.mean(y==p)),f1=float(f1_score(y,p,zero_division=0)),recall=tp/(tp+fn) if tp+fn else None,fpr=fp/(fp+tn) if fp+tn else None)
def bootstrap(g,d,seed):
    t=pd.DataFrame({'g':g,'d':d}).groupby('g').d.agg(['sum','size']);a=t['sum'].to_numpy();b=t['size'].to_numpy();rng=np.random.default_rng(seed)
    vals=[]
    for _ in range(2000):
        i=rng.integers(len(a),size=len(a));vals.append(a[i].sum()/b[i].sum())
    return np.quantile(vals,[.025,.975]).tolist()
def main():
    checks();df=pd.read_csv(ROOT/'sample.csv.gz');urls=df.URL.to_numpy();y=df.y.to_numpy();groups=df.group.to_numpy()
    protocol={'purpose':'Exploratory follow-up after the initial consistency experiment; same historical sample and splits, not a new untouched test set.','seeds':SEEDS,'operations':OPS,'primary':'Retrained normalized-only versus raw; error delta positive means worse.','secondary':'Dual representation rescue and frozen-model preprocessing mismatch.','features':'character 3-5 TF-IDF, lowercase, min_df=2, 50000 total cap; dual 25000 per view scaled by 1/sqrt(2)','classifier':'L2 logistic regression C=1 liblinear, threshold 0.5, max_iter=1000','uncertainty':'2000 paired registered-domain bootstrap resamples; exploratory percentile intervals, no multiplicity adjustment','sampling':'Existing balanced 30000 sample, inherited labels and original registered-domain groups','no_network':'No dataset URL opened or resolved','normalization_scope':'Representation ablation only: stripping www or fragments is not assumed resource-preserving.'}
    (ROOT/'protocol.json').write_text(json.dumps(protocol,indent=2))
    transformed={op:np.array([transform(u,op) for u in urls]) for op in OPS}
    audit={}
    for op,us in transformed.items():
        t=df.assign(key=us);du=t.groupby('key').agg(n=('y','size'),classes=('y','nunique'))
        audit[op]={'affected_legitimate':int(np.sum((us!=urls)&(y==0))),'affected_phishing':int(np.sum((us!=urls)&(y==1))),'distinct_outputs':int(t.key.nunique()),'collision_groups':int((du.n>1).sum()),'conflicting_label_groups':int((du.classes>1).sum())}
    (OUT/'coverage.json').write_text(json.dumps(audit,indent=2))
    rows=[];comparisons=[];splits=[];start=time.time()
    for seed in SEEDS:
        tr,te=next(GroupShuffleSplit(n_splits=1,test_size=.2,random_state=seed).split(urls,y,groups))
        assert not set(groups[tr])&set(groups[te])
        splits.append({'seed':seed,'train_n':len(tr),'test_n':len(te),'group_overlap':0})
        pd.DataFrame({'source_row':df.source_row,'split':np.where(np.isin(np.arange(len(df)),te),'test','train')}).to_csv(OUT/f'split_{seed}.csv',index=False)
        v=vectorizer();x=v.fit_transform(urls[tr]);xt=v.transform(urls[te]);base=model().fit(x,y[tr]);bp=base.predict(xt)
        predictions=pd.DataFrame({'source_row':df.source_row.iloc[te].to_numpy(),'group':groups[te],'y':y[te],'raw':bp,'raw_score':base.predict_proba(xt)[:,1]})
        rows.append(dict(seed=seed,operation='none',route='raw',subset='all',**metrics(y[te],bp)))
        vr=vectorizer(25000);xr=vr.fit_transform(urls[tr]);xrt=vr.transform(urls[te])
        # Capacity control: same dual architecture, but original URLs in both views.
        control=model().fit(hstack([xr,xr],format='csr')/np.sqrt(2),y[tr]);cp=control.predict(hstack([xrt,xrt],format='csr')/np.sqrt(2))
        predictions['duplicate_raw']=cp
        rows.append(dict(seed=seed,operation='none',route='duplicate_raw',subset='all',**metrics(y[te],cp)))
        for op,us in transformed.items():
            aff=us[te]!=urls[te];predictions[f'{op}_affected']=aff
            vn=vectorizer();xn=vn.fit_transform(us[tr]);xnt=vn.transform(us[te]);norm=model().fit(xn,y[tr]);npred=norm.predict(xnt)
            vd=vectorizer(25000);xd=vd.fit_transform(us[tr]);xdt=vd.transform(us[te]);dual=model().fit(hstack([xr,xd],format='csr')/np.sqrt(2),y[tr]);dp=dual.predict(hstack([xrt,xdt],format='csr')/np.sqrt(2))
            fp=base.predict(v.transform(us[te]))
            for route,p in [('normalized',npred),('dual',dp),('frozen',fp)]:
                predictions[f'{op}_{route}']=p
                for subset,mask in [('all',np.ones(len(te),dtype=bool)),('affected',aff)]:
                    if mask.sum():rows.append(dict(seed=seed,operation=op,route=route,subset=subset,**metrics(y[te][mask],p[mask])))
            for label,p,ref in [('normalized_vs_raw',npred,bp),('dual_vs_normalized',dp,npred),('frozen_vs_raw',fp,bp),('dual_vs_duplicate_raw',dp,cp)]:
                err=p!=y[te];old=ref!=y[te];delta=err.astype(int)-old.astype(int)
                lo,hi=bootstrap(groups[te],delta,seed)
                comparisons.append(dict(seed=seed,operation=op,comparison=label,new_errors=int(np.sum(err&~old)),corrected=int(np.sum(~err&old)),net_errors=int(delta.sum()),error_delta_pp=100*float(delta.mean()),ci_low_pp=100*lo,ci_high_pp=100*hi,affected_n=int(aff.sum()),affected_new_errors=int(np.sum(err&~old&aff)),affected_corrected=int(np.sum(~err&old&aff))))
            print(seed,op,'raw FN',int(np.sum((bp==0)&(y[te]==1))),'norm FN',int(np.sum((npred==0)&(y[te]==1))),'dual FN',int(np.sum((dp==0)&(y[te]==1))),flush=True)
        predictions.to_csv(OUT/f'predictions_{seed}.csv.gz',index=False)
        pd.DataFrame(rows).to_csv(OUT/'metrics.csv',index=False);pd.DataFrame(comparisons).to_csv(OUT/'comparisons.csv',index=False)
    (OUT/'splits.json').write_text(json.dumps(splits,indent=2))
    (OUT/'environment.json').write_text(json.dumps({'python':platform.python_version(),'versions':{n:importlib.metadata.version(n) for n in ['numpy','pandas','scipy','scikit-learn']},'elapsed_seconds':time.time()-start},indent=2))
    print('DONE',time.time()-start,flush=True)
if __name__=='__main__':
    with threadpool_limits(limits=2):main()
