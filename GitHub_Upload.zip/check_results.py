"""Recompute outcome tables directly from saved predictions; no model fitting."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from urllib.parse import urlsplit
R=Path(__file__).resolve().parent;O=R/'results'
df=pd.read_csv(R/'sample.csv.gz').set_index('source_row')
metrics=pd.read_csv(O/'metrics.csv');comps=pd.read_csv(O/'comparisons.csv')
subgroups=[];diagnostics=[];concentration=[];verified=0
for seed in [42,43,44]:
 p=pd.read_csv(O/f'predictions_{seed}.csv.gz');y=p.y.to_numpy();ids=p.source_row
 split=pd.read_csv(O/f'split_{seed}.csv');tr=split.loc[split.split=='train','source_row'];te=split.loc[split.split=='test','source_row']
 assert set(ids)==set(te)
 assert not set(df.loc[tr,'group'])&set(df.loc[te,'group'])
 assert np.array_equal(df.loc[ids,'y'],y)
 for _,r in metrics[metrics.seed==seed].iterrows():
  key=r.route if r.operation=='none' else r.operation+'_'+r.route
  mask=np.ones(len(p),bool) if r.subset=='all' else p[r.operation+'_affected'].to_numpy()
  pred=p[key].to_numpy()[mask];truth=y[mask]
  assert r.n==len(truth)
  for label,val in {'tn':np.sum((pred==0)&(truth==0)),'fp':np.sum((pred==1)&(truth==0)),'fn':np.sum((pred==0)&(truth==1)),'tp':np.sum((pred==1)&(truth==1))}.items():assert r[label]==val
  assert abs(r.accuracy-np.mean(pred==truth))<1e-12
  assert abs(r.f1-2*r.tp/(2*r.tp+r.fp+r.fn))<1e-12
  verified+=1
 for _,r in comps[comps.seed==seed].iterrows():
  route,reference=r.comparison.split('_vs_')
  k=r.operation+'_'+route;ref=reference if reference in ['raw','duplicate_raw'] else r.operation+'_'+reference
  err=p[k].to_numpy()!=y;old=p[ref].to_numpy()!=y
  assert r.new_errors==np.sum(err&~old);assert r.corrected==np.sum(~err&old)
  assert r.net_errors==r.new_errors-r.corrected
  assert abs(r.error_delta_pp-100*(err.mean()-old.mean()))<1e-10
 new=(p.www_normalized!=p.y)&(p.raw==p.y)
 a=p.assign(new=new).groupby('group').new.sum().sort_values(ascending=False)
 concentration.append({'seed':seed,'new_errors':int(new.sum()),'largest_domain_new_errors':int(a.iloc[0]),'top_three_domain_new_errors':int(a.iloc[:3].sum()),'domains_with_new_errors':int((a>0).sum())})
 www=df.loc[ids,'URL'].map(lambda u:urlsplit(u).hostname.lower().startswith('www.')).to_numpy()
 for group,mask in [('phishing_www',(y==1)&www),('phishing_nonwww',(y==1)&~www),('legitimate',y==0)]:
  for route in ['raw','www_normalized','www_dual','www_frozen','duplicate_raw']:
   subgroups.append({'seed':seed,'subgroup':group,'route':route,'n':int(mask.sum()),'errors':int(np.sum((p[route].to_numpy()!=y)&mask))})
 # Post-hoc diagnostic, explicitly fitted only to training labels.
 train=df.loc[tr];train_www=train.URL.map(lambda u:urlsplit(u).hostname.lower().startswith('www.'))
 rule=train.assign(www=train_www).groupby('www').y.mean().ge(.5).astype(int).to_dict()
 pred=np.array([rule[v] for v in www]);diagnostics.append({'seed':seed,'www_rule_accuracy':float(np.mean(pred==y)),'rule':{str(k):v for k,v in rule.items()}})
pd.DataFrame(subgroups).to_csv(O/'www_subgroups.csv',index=False)
(O/'error_concentration.json').write_text(json.dumps(concentration,indent=2))
(O/'shortcut_diagnostic.json').write_text(json.dumps(diagnostics,indent=2))
(O/'verification.json').write_text(json.dumps({'metric_rows_recomputed':verified,'paired_comparisons_verified':len(comps),'domain_overlap':0,'status':'passed'},indent=2))
print('Verified',verified,'metric rows and',len(comps),'paired comparisons.')
