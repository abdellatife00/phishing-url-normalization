# URL normalization and phishing classification

This repository contains the data, code and saved predictions for an offline study of how URL preprocessing affects a character-based phishing classifier. The sample contains 30,000 labeled historical URLs from PhiUSIIL. Each test split holds out entire registered domains.

## Reproduce the findings

Run these commands from this directory with Python 3.12.

```sh
python -m pip install -r requirements.txt
python experiment.py
python check_results.py
```

To verify the reported results from the bundled predictions without retraining, install the requirements and run only `python check_results.py`.

`protocol.json` records the experimental design. `source_data_audit.json` documents sampling and dataset provenance. The `results` directory contains test predictions for each split, split assignments, metrics, and paired comparisons. `Sources_and_Claim_Checks.md` documents the supporting references.

The main experiment fits 30 classifiers: original-only, duplicate-original control, and normalized-only plus dual for each of four operations across three splits. Frozen comparisons reuse the original-only model. Hyperparameters are fixed. Runs may vary slightly with numerical-library versions; the versions actually used are in results/environment.json. Use the bundled predictions to inspect the exact reported results.

## Interpretation
The same sample and splits were examined in an earlier experiment. This is an exploratory follow-up, not a preregistered or untouched confirmatory evaluation. www and root-path composition were already known to be biased. The www-only rule and concentration calculations are post-hoc diagnostics. The reported confidence intervals condition on fitted models and do not adjust for multiple comparisons.

Removing www and fragments is an internal representation experiment, not a claim that those strings always refer to the same resource. All transformed inputs inherit the original dataset label. No external security product was tested. One qualifying percent-encoded URL is insufficient for a general decoding conclusion.

## Dataset attribution
Prasad, A., & Chandra, S. (2024). PhiUSIIL phishing URL (website) [Data set]. UCI Machine Learning Repository.
https://archive.ics.uci.edu/dataset/967/phiusiil+phishing+url+dataset

The dataset is licensed CC BY 4.0. This package contains a selected subset, remapped reporting labels, original row identifiers and derived domain groups. The original data were filtered and deduplicated as described in the paper. No claim of ownership of the original data is made.

## AI assistance
ChatGPT assisted with research planning, code development, analysis, and language editing. The student should understand and review the work before submission.

